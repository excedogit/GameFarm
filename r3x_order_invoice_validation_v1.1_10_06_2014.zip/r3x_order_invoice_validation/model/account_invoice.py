# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.osv import fields, osv, orm
from openerp.tools.translate import _
import re

class account_invoice_validate(osv.osv):
    _name="account.invoice.validate"

class account_invoice(osv.osv):
    _inherit="account.invoice"
    
    def invoice_validate(self, cr, uid, ids, context=None):
        res=super(account_invoice,self).invoice_validate(cr,uid,ids,context)
        invoice_line=self.pool.get('account.invoice.line')
        in_ids=invoice_line.search(cr,uid,[('invoice_id','=',ids[0])])
        for product in invoice_line.browse(cr,uid,in_ids):
            
            if (product.product_id.type=='product'):
                invoice_obj=self.browse(cr,uid,ids,context)[0]
                picking_obj=self.pool.get('stock.picking.out')
                
                # Matching The Supplier Invoices...............
                print "Here is the User ID::",uid
                cr.execute("select gid from res_groups_users_rel where uid=%s and gid=(select id from res_groups where name='Financial Manager')"%uid)
                groups=cr.dictfetchall()
                print "Groups Of Particular User ::",groups
                
                if re.search('INV',invoice_obj.number) and (len(groups)>=1):
                    self.write(cr, uid, ids, {'state':'open'}, context=context)
                    #view_id = self.pool.get('ir.ui.view').search(cr,uid,[('name', '=', 'account.invoice.validate')])
                    #view_ref = self.pool.get('ir.model.data').get_object_reference(cr, uid, 'account_invoice')
                    #dummy, view_id = self.pool.get('ir.model.data').get_object_reference(cr, uid,'account_invoice','action_invoice_validation')
                    #view_id = view_ref and view_ref[1] or False
                    #print "View Id Here Is ::", view_id

                    return {
                            'name':_("Select Payments for Deposit"),
                            'view_mode': 'form',
                            'view_id': False,
                            'view_type': 'form',
                            'res_model': 'account.invoice.validate',
                            'type': 'ir.actions.act_window',
                            'nodestroy': True,
                            'target': 'new',
                            'domain': '[]',
                            'context': context
                            }
                   # raise osv.except_osv(_('Warning'),
                   #                          _('No delivery order existed with this invoice') )
                
                elif re.search('INV',invoice_obj.number):
                    if (product.product_id.sale_ok== True and product.product_id.valuation == 'real_time'):
                        if not invoice_obj.picking_ids:
                            raise osv.except_osv(_('Error!'),
                                             _('No delivery order existed with this invoice, ' \
                                               'Please create Delivery Order') )
                
                #Matching the Customer Invoice..................
                elif re.search('EXJ',invoice_obj.number):
                    if (product.product_id.purchase_ok== True and product.product_id.valuation == 'real_time'):
                        if not invoice_obj.picking_ids:
                            raise osv.except_osv(_('Error!'),
                                                 _('No incoming shipment existed with this invoice, ' \
                                                   'Please create Purchase Order') )
                    
            else:
                pass
                    
        return res 
                