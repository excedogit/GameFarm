# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2013 Excedo Technologies  & Solutions Pvt. Ltd.
#    (http://wwww.excedo.in)
#    contact@zbeanztech.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.osv import fields,osv
from openerp.tools.translate import _

class sale_order(osv.osv):
    _inherit = 'sale.order'
    
    _columns={
               'mode_of_transport':fields.char('Mode Of Transport',size=64),
               'port_marks':fields.char('Port Marks',size=64),
               'port_loading':fields.char('Port of Loading',size=64),
               'port_discharge':fields.char('Port of Discharge',size=64),
               'flight':fields.char('Flight',size=64),
               'depature_date':fields.date('Depature Date'),
               'via':fields.char('Via',size=64),
               }
    
class purchase_order(osv.osv):
    _inherit = 'purchase.order'
    
    _columns={
               'mode_of_transport':fields.char('Mode Of Transport',size=64),
               'port_marks':fields.char('Port Marks',size=64),
               'port_loading':fields.char('Port of Loading',size=64),
               'port_discharge':fields.char('Port of Discharge',size=64),
               'flight':fields.char('Flight',size=64),
               'depature_date':fields.date('Depature Date'),
               'via':fields.char('Via',size=64),
               'cosignee':fields.char('Cosignee',size=128),
               }
    
class account_invoice(osv.osv):
    _inherit = 'account.invoice'
    
    _columns={
               'mode_of_transport':fields.char('Mode Of Transport',size=64),
               'port_marks':fields.char('Port Marks',size=64),
               'port_loading':fields.char('Port of Loading',size=64),
               'port_discharge':fields.char('Port of Discharge',size=64),
               'flight':fields.char('Flight',size=64),
               'depature_date':fields.date('Depature Date'),
               'via':fields.char('Via',size=64),
               }
    
class stock_picking_out(osv.osv):
    _inherit = 'stock.picking.out'
    
    _columns={
               'mode_of_transport':fields.char('Mode Of Transport',size=64),
               'port_marks':fields.char('Port Marks',size=64),
               'port_loading':fields.char('Port of Loading',size=64),
               'port_discharge':fields.char('Port of Discharge',size=64),
               'flight':fields.char('Flight',size=64),
               'depature_date':fields.date('Depature Date'),
               'via':fields.char('Via',size=64),
               }    
    