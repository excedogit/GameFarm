# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2013 ZestyBeanz Technologies Pvt. Ltd.
#    (http://wwww.zbeanztech.com)
#    contact@zbeanztech.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from datetime import datetime, timedelta
from openerp.osv import osv, fields
from openerp.tools.translate import _

class update_run_wizard(osv.osv_memory):
    _name = "update.run.wizard"
    _columns = {
        'name': fields.char('Name',size=64),
        'line_ids': fields.one2many('update.run.wizard.line','wizard_id','Lines'),    
                
    }
    
    def default_get(self, cr, uid, fields, context=None):
        if context is None:
            context = {}
        temp_dict = {}
        pack_dict = {}
        active_ids = context.get('active_ids', [])
        active_model = context.get('active_model')
        assert active_model in ('stock.delivery.fulfillment', ), 'Bad context propagation'
        res = super(update_run_wizard, self).default_get(cr, uid, fields, context=context)
        fulfillment_pool = self.pool.get('stock.delivery.fulfillment')
        record_ids = context and context.get('active_ids', [])
        record_id = record_ids and record_ids[0] or False
        fulfillment_obj = fulfillment_pool.browse(cr, uid, record_id, context=context)
        if fulfillment_obj.fullfilment_line_ids:
            for line in fulfillment_obj.fullfilment_line_ids:
                if line.order_id.id not in pack_dict:
                    pack_dict[line.order_id.id] = []
                pack_dict[line.order_id.id].append(line.pack_number)
                if line.order_id.id not in temp_dict:
                    temp_dict[line.order_id.id]= {'partner_id':line.partner_id and line.partner_id.id or False,
                                                  'order_id':line.order_id and line.order_id.id or False,
                                                  'run_id': line.run_id and line.run_id.id or False,
                                                  
                                                  }
        items = []
        for key in temp_dict:
            item = temp_dict[key]
            item.update({'pack_number':max(list(set(pack_dict[key]))) })
            items.append(item)
        res.update({'line_ids':[(0,0,itm) for itm in items],
                    'name': 'Update Details'})
        return res
    
    def proceed(self, cr, uid, ids, context=None):
        if context is None:
             context = {}
        active_ids = context.get('active_ids', [])
        active_model = context.get('active_model')
        assert active_model in ('stock.delivery.fulfillment', ), 'Bad context propagation'
        fulfillment_line_pool = self.pool.get('stock.delivery.fulfillment.line')
        data = self.browse(cr, uid, ids[0],) 
        record_id = context and context.get('active_id', False)
        picking_dict = {}
        for line in data.line_ids:
            if not line.run_id:
                raise osv.except_osv(_('Error!'),
                            _('Please provide a Run for the Sale Order %s'%line.order_id.name))
            fulfillment_line_ids = fulfillment_line_pool.search(cr, uid, [('fullfilment_id','=',record_id),
                                                                          ('partner_id','=',line.partner_id.id),
                                                                          ('order_id','=',line.order_id.id)])
            fulfillment_line_pool.write(cr, uid, fulfillment_line_ids ,{'run_id': line.run_id.id,'pack_number':line.pack_number})
            for fline in fulfillment_line_pool.browse(cr, uid, fulfillment_line_ids):
                for move in fline.move_lines:
                    if move.picking_id and move.picking_id.id not in picking_dict:
                        move.picking_id.write({'run_id':line.run_id.id,'number_of_packages':line.pack_number})
                        picking_dict['move.picking_id.id'] = True
        return True
    
    
update_run_wizard()
  
class update_run_wizard_line(osv.osv_memory):
    _name = "update.run.wizard.line"
    _columns = {
        'wizard_id': fields.many2one('update.run.wizard','Update Run'),
        'order_id': fields.many2one('sale.order','Sale Order'),
        'partner_id': fields.many2one('res.partner','Customer'),
        'run_id': fields.many2one('crm.lead.run', 'Run'),
        'pack_number': fields.integer('Pack Number'),
        'fulfillment_line_id': fields.many2one('stock.delivery.fulfillment.line', 'Line'),
                
    }
    _order = 'partner_id'
update_run_wizard_line()  
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: 