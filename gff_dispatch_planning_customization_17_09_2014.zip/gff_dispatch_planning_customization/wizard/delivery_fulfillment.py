# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2013 ZestyBeanz Technologies Pvt. Ltd.
#    (http://wwww.zbeanztech.com)
#    contact@zbeanztech.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from datetime import datetime, timedelta
from openerp.osv import osv, fields
from openerp.tools.translate import _
from lxml import etree
from openerp.osv.orm import setup_modifiers
import openerp.addons.decimal_precision as dp
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, \
    DEFAULT_SERVER_DATETIME_FORMAT

class delivery_fulfillment_wizard(osv.osv_memory):
    _inherit = "delivery.fulfillment.wizard"
    _columns = {
       
        'line_ids2': fields.one2many('delivery.fulfillment.wizard.line2',
                                                          'wizard_id','Lines'),
        'uos_id': fields.many2one('product.uom','Uos'),
        'sale_description': fields.char('Sale Description',size =64),
        'backorder_needed': fields.boolean('Consider for Backorder',help="If checked, then it will be considered for creating sale quotation."),
        'allow_negative': fields.boolean('Allow Negative Quantity'),
    }
    
    
    def onchange_line_ids(self, cr, uid, ids, lines,order_qty,allow_negative, context=None):
        result = {'value':{}}
        total_entered_qty = 0.0
        cust_plan_pool = self.pool.get('delivery.fulfillment.wizard.line2')
        for line in lines:
            if not line[-1]:
                tot = cust_plan_pool.read(cr, uid,line[1],['date_qty'])['date_qty']
                total_entered_qty += tot or 0.0
                continue
            if 'date_qty' in line[-1]:
                total_entered_qty += line[-1]['date_qty']
        if total_entered_qty > order_qty and allow_negative == False:
            result['warning'] = {
                    'title': _('Warning!'),
                    'message': _('Total Allocated Quantity is greater than the customer order quantity')
                }
        else:
            result['value'] = {'actual_qty': total_entered_qty}
        return result
    
    def save_fulfillment(self, cr, uid, ids, context=None):
        actual_quantity = 0.00
        fulfillment_line_pool = self.pool.get('stock.delivery.fulfillment.line')
        if context.get('plan_state',False) == 'done':
            return True
        wiz_obj =self.browse(cr, uid, ids,)[0]
        for line2 in wiz_obj.line_ids2:
            actual_quantity += line2.date_qty
#         if actual_quantity > wiz_obj.order_qty:
#             raise osv.except_osv(_('Error!'), _('You cannot plan a quantity greater than order quantity.'))
        product_obj = wiz_obj.product_id
        dispatch_date = datetime.strptime(wiz_obj.delivery_date, \
                                        DEFAULT_SERVER_DATE_FORMAT) + timedelta(days=0)
        date_format = self.pool.get('stock.production.lot')._get_date_format(cr, uid, context)
#         for line in wiz_obj.line_ids:
        fulfillment_line_pool.write(cr,uid, wiz_obj.fullfilment_line_id.id,{
            'backorder_needed':wiz_obj.backorder_needed, 
            'sale_description':wiz_obj.sale_description,                             
            'actual_qty': actual_quantity,
            'actual_uom_id':wiz_obj.actual_uom_id.id,
            'run_id': wiz_obj.run_id.id,
            'is_loaded':True,
            'state':'approved',
            'pack_number': wiz_obj.pack_number,
            'remarks': wiz_obj.remarks,
        })
        ful_line = fulfillment_line_pool.browse(cr,uid, wiz_obj.fullfilment_line_id.id)
        i=0
        for line in ful_line.planned_lines:
            self.pool.get('delivery.fulfillment.planned.lines').write(cr, uid, line.id, {    
                 'order_id':wiz_obj.order_id.id,
                 'date_qty':wiz_obj.line_ids2[i].date_qty,
                 'plan_qty':wiz_obj.line_ids2[i].plan_qty,
                 'actual_qty':wiz_obj.line_ids2[i].actual_qty,
                 'weight': wiz_obj.line_ids2[i].weight,
                 'location_id': wiz_obj.line_ids2[i].location_id and \
                        wiz_obj.line_ids2[i].location_id.id or False
                 }, context=context)
            i=i+1
        return True
    
    def fields_view_get(self, cr, uid, view_id=None, view_type='form', context=None, toolbar=False, submenu=False):
        result = super(delivery_fulfillment_wizard, self).fields_view_get(cr, uid, view_id=view_id, view_type=view_type, context=context, toolbar=toolbar, submenu=submenu)
        if context is None:
            context = {}
        if context.get('plan_state','') == 'done':
            doc = etree.XML(result['arch'])
            nodes = doc.xpath("//field[@name='line_ids2']")
            for node in nodes:
                node.set('readonly', '1')
                setup_modifiers(node, result['fields']['line_ids2'])
#             result['arch'] = etree.tostring(doc)
#             doc = etree.XML(result['arch'])
            nodes = doc.xpath("//field[@name='backorder_needed']")
            for node in nodes:
                node.set('readonly', '1')
                setup_modifiers(node, result['fields']['backorder_needed'])
            result['arch'] = etree.tostring(doc)
        return result
delivery_fulfillment_wizard()

class delivery_fulfillment_wizard_line2(osv.osv_memory):
    _name = "delivery.fulfillment.wizard.line2"
    
    _columns = {
        'order_qty': fields.float('Order Quantity'),
        'wizard_id': fields.many2one('delivery.fulfillment.wizard','fullfillment'),
        'fullfilment_line_id': fields.many2one('stock.delivery.fulfillment.line','Fullfilment Line'),
        'date': fields.date('Date'),
        'lot_id': fields.many2one('stock.production.lot','Serial Number'),
        'weight': fields.float('UOS quantity'),
        'actual_qty': fields.float('Available Quantity'),
        'plan_qty': fields.float('Planned Quantity'),
        'date_qty': fields.float('Actual Quantity ', digits_compute=dp.get_precision('Product Unit of Measure')),
        'location_id': fields.many2one('stock.location','Bin Location'),
        'location_id1': fields.char('Bin Location',size=128),
        'allow_negative': fields.boolean('Allow Negative Quantity'),
    }

    def onchange_date_qty(self,cr ,uid,ids, date_qty ,allow_negative,context=None):
        wiz_obj =self.browse(cr, uid, ids,)[0]
        warning ={}
        weight = wiz_obj.lot_id.product_id.uos_coeff * date_qty
        if (wiz_obj.actual_qty < date_qty) and allow_negative == False:
            value = {'date_qty': wiz_obj.date_qty ,'weight': wiz_obj.weight }
            warning = {
            'title': _('Warning!'),
            'message' : _('Available quantity on %s is %s Qty.'
                                        'You are trying to plan for %s Qty.'%(wiz_obj.date,
                                                            wiz_obj.actual_qty,date_qty))
            }
        else:
            value = {'weight': weight}
        return {'value': value, 'warning': warning}
    
    def onchange_weight(self,cr ,uid,ids, weight, date_qty,context=None):
        value = {}
        warning ={}
        wiz_obj =self.browse(cr, uid, ids,)[0]
        factor = wiz_obj.wizard_id.product_id and wiz_obj.wizard_id.product_id.eff_factor
        weight1  = wiz_obj.lot_id.product_id.uos_coeff * date_qty
        allowed_weight_max = weight1 + ((weight1 * (factor * 10)) / 100)
        allowed_weight_min = weight1 - ((weight1 * (factor * 10)) / 100)
        if (weight > allowed_weight_max) or (weight < allowed_weight_min):
            value = {}
            warning = {
            'title': _('Warning!'),
            'message' : _('Weight is greater than or less than the allowed quantity')
            }
        return {'value': value, 'warning': warning}
    
delivery_fulfillment_wizard_line2()