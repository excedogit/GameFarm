# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2013 ZestyBeanz Technologies Pvt. Ltd.
#    (http://wwww.zbeanztech.com)
#    contact@zbeanztech.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.osv import fields, osv

class stock_config_settings(osv.osv_memory):
    _inherit = 'stock.config.settings'
    
    _columns = {
                'consider_for_backorder': fields.boolean("Consider for Backorder"),
                'allow_negative_qty': fields.boolean("Allow Negative Quantity"),
                }
#     def execute(self, cr, uid, ids, context=None):
#         if context is None:
#             context = {}
#         record = self.browse(cr, uid, ids, context=context)[0]
#         need_backorder = record.consider_for_backorder or False
#         allow_negative = record.allow_negative_qty
#         ir_values_obj = self.pool.get("ir.values")
#         res =  super(stock_config_settings, self).execute(cr, uid, ids, context=context)
#         ir_values_obj.set(cr, uid, key='default', key2=False, name='backorder_needed', models =[('stock.delivery.fulfillment.line', False)], value=need_backorder)
#         ir_values_obj.set(cr, uid, key='default', key2=False, name='backorder_needed', models =[('delivery.fulfillment.wizard', False)], value=need_backorder)
#         ir_values_obj.set(cr, uid, key='default', key2=False, name='allow_negative', models =[('delivery.fulfillment.wizard.line2', False)], value=allow_negative)
#         ir_values_obj.set(cr, uid, key='default', key2=False, name='allow_negative', models =[('delivery.fulfillment.wizard', False)], value=allow_negative)
#         return res

    def get_default_backorder(self, cr, uid, ids, context=None):
#         guid_value = self.pool.get("ir.config_parameter").get_param(cr, uid, "need.back.order", context=context)
        ir_values = self.pool.get("ir.values")
        backorder= ir_values.get_default(cr, uid, 'stock.delivery.fulfillment.line', 'backorder_needed1')
        allow_negative = ir_values.get_default(cr, uid, 'delivery.fulfillment.wizard', 'allow_negative')
        return {'consider_for_backorder': backorder or False,
                'allow_negative_qty': allow_negative or False}

    def set_default_backorder(self, cr, uid, ids, context=None):
        ir_values = self.pool.get("ir.values")
        config = self.browse(cr, uid, ids[0], context)
        ir_values.set_default(cr, uid, 'delivery.fulfillment.wizard', 'backorder_needed',
                config.consider_for_backorder or False)
        ir_values.set_default(cr, uid, 'stock.delivery.fulfillment.line', 'backorder_needed1',
                config.consider_for_backorder or False)
        ir_values.set_default(cr, uid, 'delivery.fulfillment.wizard.line2', 'allow_negative',
                config.allow_negative_qty or False)
        ir_values.set_default(cr, uid, 'delivery.fulfillment.wizard', 'allow_negative',
                config.allow_negative_qty or False)
#         config_parameters = self.pool.get("ir.config_parameter")
#         for record in self.browse(cr, uid, ids, context=context):
#             config_parameters.set_param(cr, uid, "need.back.order", record.consider_for_backorder or '', context=context)
            
#     def get_default_allow_negative(self, cr, uid, ids, context=None):
#         guid_value = self.pool.get("ir.config_parameter").get_param(cr, uid, "allow.negative.value", context=context)
#         return {'allow_negative_qty': guid_value}
# 
#     def set_default_allow_negative(self, cr, uid, ids, context=None):
#         config_parameters = self.pool.get("ir.config_parameter")
#         for record in self.browse(cr, uid, ids, context=context):
#             config_parameters.set_param(cr, uid, "allow.negative.value", record.allow_negative_qty or '', context=context)

stock_config_settings()
