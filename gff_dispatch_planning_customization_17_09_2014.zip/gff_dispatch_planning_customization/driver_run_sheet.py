# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2013 ZestyBeanz Technologies Pvt. Ltd.
#    (http://wwww.zbeanztech.com)
#    contact@zbeanztech.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from datetime import datetime, timedelta
from openerp import SUPERUSER_ID, netsvc
from openerp.osv import osv, fields
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, \
    DEFAULT_SERVER_DATETIME_FORMAT
from openerp.tools.safe_eval import safe_eval as eval
from openerp.tools.translate import _

class driver_run_sheet_line(osv.osv):
    _inherit = "driver.run.sheet.line"
    
    def get_pack_number(self, cr, uid, ids, prop, unknow_none, context=None):
        res = {}
        
        for record in self.browse(cr, uid, ids, context=context):
            pack_numbers = 0
            for picking in record.picking_ids:
                pack_numbers += picking.number_of_packages or 0
                
            res[record.id] = pack_numbers
        return res
    _columns = {
        'pack_numbers': fields.function(get_pack_number,type="integer",string="Pack Numbers")
    }
        
driver_run_sheet_line()


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: