# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2013 ZestyBeanz Technologies Pvt. Ltd.
#    (http://wwww.zbeanztech.com)
#    contact@zbeanztech.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from datetime import datetime, timedelta
from openerp import SUPERUSER_ID, netsvc
from openerp.osv import osv, fields
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, \
    DEFAULT_SERVER_DATETIME_FORMAT
from openerp.tools.safe_eval import safe_eval as eval
from openerp.tools.translate import _

class dispatch_planning(osv.osv):
    _inherit = 'stock.dispatch.planning'

    def view_delivery_fulfillment(self, cr, uid, ids, context=None):
        if isinstance(ids,(int,long)):
            ids = [ids]
        obj_model = self.pool.get('ir.model.data')
        model_data_ids = obj_model.search(cr,uid,[('model','=','ir.ui.view'),('name','=','stock_delivery_fulfillment_form')])
        resource_id = obj_model.read(cr, uid, model_data_ids, fields=['res_id'])[0]['res_id']
        disp_obj = self.browse(cr, uid, ids, context)[0]
        fulfil_id = disp_obj.fulfillment_id.id or False
        return {
                        'view_type': 'form',
                        'view_mode': 'form',
                        'view_id': [resource_id],
                        'res_model': 'stock.delivery.fulfillment',
                        'type': 'ir.actions.act_window',
                        'nodestroy': True,
                        'target': 'current',
                        'res_id': fulfil_id or False,
                       }
        
dispatch_planning()


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: