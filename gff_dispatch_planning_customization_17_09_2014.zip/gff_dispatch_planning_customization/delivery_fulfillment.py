# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2013 ZestyBeanz Technologies Pvt. Ltd.
#    (http://wwww.zbeanztech.com)
#    contact@zbeanztech.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from datetime import datetime, timedelta
import time
from openerp.osv import osv, fields
from itertools import chain
from openerp import netsvc
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, \
    DEFAULT_SERVER_DATETIME_FORMAT

class stock_delivery_fulfillment(osv.osv):
    _inherit = "stock.delivery.fulfillment"
    
    _columns = {
                'drs_id': fields.many2one('driver.run.sheet','Driver Run Sheet')
                }
    
    def view_drs(self, cr, uid, ids, context=None):
        if isinstance(ids,(int,long)):
            ids = [ids]
        obj_model = self.pool.get('ir.model.data')
        model_data_ids = obj_model.search(cr,uid,[('model','=','ir.ui.view'),('name','=','driver_run_sheet_form')])
        resource_id = obj_model.read(cr, uid, model_data_ids, fields=['res_id'])[0]['res_id']
        fulfil_obj = self.browse(cr, uid, ids, context)[0]
        drs_id = fulfil_obj.drs_id.id or False
        return {
                        'view_type': 'form',
                        'view_mode': 'form',
                        'view_id': [resource_id],
                        'res_model': 'driver.run.sheet',
                        'type': 'ir.actions.act_window',
                        'nodestroy': True,
                        'target': 'current',
                        'res_id': drs_id or False,
                       }
    def update_customer_run(self, cr, uid, ids, context=None):
        if isinstance(ids,(int,long)):
            ids = [ids]
        obj_model = self.pool.get('ir.model.data')
        model_data_ids = obj_model.search(cr,uid,[('model','=','ir.ui.view'),('name','=','update_run_wizard_form')])
        resource_id = obj_model.read(cr, uid, model_data_ids, fields=['res_id'], context=context)[0]['res_id']
        context= context.copy()
        context.update({'active_model':'stock.delivery.fulfillment',
                        'active_ids': ids})
        return {
                'name': 'Update Details',
                'view_type': 'form',
                'view_mode': 'form',
                'view_id': [resource_id],
                'res_model': 'update.run.wizard',
                'type': 'ir.actions.act_window',
                'target': 'new',
                'context': context,
                       }
    
    def update_and_modify_moves(self, cr, uid, ids,line,move_list, context=None):
        result = {}
        return result
    
    def create_driver_run_sheet(self, cr, uid, ids, drs_dict,picking_dict,context=None):
        result = {}
        return result

    def button_process(self, cr, uid, ids, context=None):
        self.button_approve_fullfilment(cr, uid, ids, context=context)
        #res = super(stock_delivery_fulfillment,self).button_process(cr, uid, ids, context)
        sale_dict = {}
        delivery_dict = {}
        temp_dict = {}
#         sale_orders =[]
        partner_dict = {}
        drs_line_pool = self.pool.get('driver.run.sheet.line')
        drs_pool = self.pool.get('driver.run.sheet')
        stock_picking_pool  = self.pool.get('stock.picking')
        partial_picking_pool = self.pool.get('stock.partial.picking')
        move_pool = self.pool.get('stock.move')
        wf_service = netsvc.LocalService("workflow")
        drs_dict = {}
        pack_number_dict = {}
        fulful_obj = self.browse(cr, uid, ids, context)[0]
        ir_values = self.pool.get("ir.values")
        backorder_needed = ir_values.get_default(cr, uid, 'stock.delivery.fulfillment.line', \
                                                     'backorder_needed1') or False
        for ful_line in fulful_obj.fullfilment_line_ids:
#             sale_orders.append(ful_line.order_id)
            partner_id = ful_line.partner_id.id
            if ful_line.sale_line_id and ful_line.order_id:
                partner_id = ful_line.order_id.partner_shipping_id and ful_line.order_id.partner_shipping_id.id or \
                        ful_line.order_id.partner_id.id
#                 for mv in ful_line.sale_line_id.move_ids:
#                     if mv.picking_id.partner_id:
#                         partner_id = mv.picking_id.partner_id.id
#                         break
            if partner_id not in drs_dict:
                drs_dict[partner_id] = {
                    'delivery_date':fulful_obj.delivery_date,
                    'run_id': ful_line.run_id.id,
                    'partner_id': partner_id,
                    'pack_qty': 0.0,
                    'picking_ids': [],
                    'fulfillment_line_ids':[]
                }
                pack_number_dict[partner_id] = []
            if ful_line.pack_number not in pack_number_dict[partner_id]:
                pack_number_dict[partner_id].append(ful_line.pack_number)
                drs_dict[partner_id]['pack_qty']+=1.0
            if ful_line.actual_qty > 0.0:
                drs_dict[partner_id]['fulfillment_line_ids'].append(ful_line.id)
            
#             move_lines = [m for m in ful_line.move_lines]
            for line2 in ful_line.planned_lines:
                 if line2.date_qty > 0.00:
                     if line2.order_id.id in delivery_dict:
                        delivery_dict[line2.order_id.id].append([line2, ful_line])
                     else:
                         delivery_dict[line2.order_id.id] = [[line2, ful_line]]
            difference =  ful_line.order_qty -ful_line.actual_qty
            
            if difference > 0.00 and (ful_line.backorder_needed or backorder_needed):
                if sale_dict.get(ful_line.order_id, []):
                   sale_dict[ful_line.order_id].append([ful_line.product_id, difference])
                else:
                    sale_dict[ful_line.order_id] = [[ful_line.product_id, difference]]
        for key,value in sale_dict.items():
            datenow = fields.date.context_today(self,cr, uid, context)
            deliver_date = datetime.strptime(key.deliver_date, \
                                             DEFAULT_SERVER_DATE_FORMAT).date()
            if key.deliver_date <= datenow:
                 deliver_date = (deliver_date + timedelta(days=1)).strftime(DEFAULT_SERVER_DATE_FORMAT)
            sale_id = self.pool.get('sale.order').copy(cr, uid, key.id,{'order_line': False,
                                                                  'deliver_date': deliver_date,
                                                                  'origin': key.name,
                                                             }) 
#             self.pool.get('sale.order').write(cr, uid,sale_id, {
#                                                                 'deliver_date': deliver_date
#                                                                 })
            order=[]
            for line_detail in value:
                order_line_obj=self.pool.get('sale.order.line')
                order=order_line_obj.search(cr,uid,[('order_id','=',key.id),('product_id','=',line_detail[0].id)])
                price_unit=order_line_obj.browse(cr,uid,order,context)[0].price_unit
                    #
                    # Changed Product Standard Price to Sale Order Price
                    # line_detail[0].standard_price relaced with price_unit
                    # 
                
                self.pool.get('sale.order.line').create(cr, uid,{'name': line_detail[0].name,         
                                                                 'product_id': line_detail[0].id,
                                                                 'product_uom':line_detail[0].uom_id.id,
                                                                 'price_unit':price_unit,
                                                                 'product_uom_qty':line_detail[1],
                                                                 'order_id': sale_id,
                                                                 'product_uom_qty':line_detail[1],
                                                                 'sale_product_uom_qty': line_detail[1],
                                                                 'sale_product_uom': line_detail[0].uom_id.id,
                                                                 })
        pack_number_pick_dict = {}
        for key,value in delivery_dict.items():
            move_to_delete = []
            for detail in value:
                move_lines = [m for m in detail[1].move_lines]
                if not move_lines: continue
                if move_lines[0].picking_id.id not in pack_number_pick_dict:
                    pack_number_pick_dict[move_lines[0].picking_id.id] = True
                    move_lines[0].picking_id.write({'number_of_packages':detail[1].pack_number})
                move_to_delete.extend(move_lines)
                move_id = move_pool.copy(cr, uid, move_lines[0].id,{'product_qty': detail[0].date_qty,
                                                   'product_uos_qty': detail[0].weight,
                                                   'prodlot_id': detail[0].lot_id.id,
                                                   'state': 'assigned'})
#                 move_pool.write(cr, uid, move_id,{'product_qty': detail[0].date_qty,
#                                                    'product_uos_qty': detail[0].weight,
#                                                    'prodlot_id': detail[0].lot_id.id,
#                                                    'state': 'assigned'})
                move = move_pool.browse(cr, uid, move_id)
                if move.picking_id.id not in temp_dict:
                    temp_dict[move.picking_id.id] = []
                temp_dict[move.picking_id.id].append((0,0,{
                                                 'product_id' : move.product_id.id,
                                                 'move_id': move.id,
                                                 'quantity': move.product_qty,
                                                 'product_uom' : move.product_uom.id,
                                                 'prodlot_id' : move.prodlot_id.id,
                                                 'location_id' : move.location_id.id,
                                                 'location_dest_id' : move.location_dest_id.id,
                                             }))
                self.pool.get('stock.delivery.fulfillment.line').write(cr, uid, detail[1].id, {'move_id': move_id})
                detail[1].refresh()
            move_procurements = [m.procurements for m in move_to_delete]
            move_procurements = list(chain.from_iterable(move_procurements))
            move_procurements = list(set(move_procurements))
            self.pool.get('procurement.order').write(cr, uid, [p.id for p in move_procurements], {'state': 'done'})
            move_to_delete_ids = [m.id for m in move_to_delete]
            move_to_delete_ids = list(set(move_to_delete_ids))
            move_pool.unlink(cr, uid, move_to_delete_ids,context={'call_unlink':True})
        drs_id = drs_pool.create(cr, uid, {'delivery_date':fulful_obj.delivery_date,
                                           'run_ids':[(6,0,[run.id for run in fulful_obj.run_ids])],
                                           'all_runs': fulful_obj.all_runs,
                                           'run_name': fulful_obj.run_name,
                                           })
        for picking_id in temp_dict:
            del_obj = self.pool.get('stock.picking').browse(cr, uid, picking_id)
            partial_id = partial_picking_pool.create(cr, uid, {
                 'picking_id':picking_id,
                 'date':fulful_obj.delivery_date,
                 'move_ids':temp_dict[picking_id]
            },context={'active_model':'stock.picking.out','active_ids':[picking_id]})
            partial_picking_pool.do_partial(cr, uid,[partial_id], context={'active_model':'stock.picking.out'})
            
            if del_obj.state != 'done':
                if del_obj.backorder_id:
                    picking_id = del_obj.backorder_id.id
            stock_picking_pool.write(cr, uid, picking_id,{'invoice_state': '2binvoiced','drs_id':drs_id})
            stock_invoice_id = self.pool.get('stock.invoice.onshipping').create(cr, uid,{
                'invoice_date':fulful_obj.delivery_date,
            },context={'active_model':'stock.picking.out','active_ids':[picking_id]})
            
            
                
            invoice_dict = self.pool.get('stock.invoice.onshipping').df_create_invoice(cr, uid, [stock_invoice_id],
                                               context={'active_model':'stock.picking.out', 'active_id':picking_id, 'active_ids':[picking_id]})
            
            for inv_id in invoice_dict.values():
                wf_service.trg_validate(uid, 'account.invoice', inv_id, 'invoice_open', cr)
                wf_service.trg_write(uid, 'account.invoice', inv_id, cr)
                self.pool.get('account.invoice').write(cr, uid,inv_id,{'drs_id':drs_id})
        self.write(cr, uid, ids, {'drs_id': drs_id},context)
        for picking_id in temp_dict:
            picking = stock_picking_pool.browse(cr, uid, picking_id)
            if picking.partner_id.id in drs_dict:
                drs_dict[picking.partner_id.id]['picking_ids'].append(picking)
            else:
                pass#TODO
        for drs in drs_dict.values():
            if drs['fulfillment_line_ids']:
                tmp = drs.copy()
                tmp['name'] = ', '.join([pick.name for pick in drs['picking_ids']])
                tmp['picking_ids'] = [(6,0,[pick.id for pick in drs['picking_ids']])]
                tmp['fulfillment_line_ids'] =  [(6,0,drs['fulfillment_line_ids'])]
                tmp['drs_id'] =  drs_id
                drs_line = drs_line_pool.create(cr, uid, tmp)
#                 drs_line_pool.write(cr, uid, drs_line, {'drs_id': drs_id})
                stock_picking_pool.write(cr, uid, [pick.id for pick in drs['picking_ids']],{'drs_id': drs_id})
        drs_pool.write(cr, uid, drs_id, {'state': 'confirmed'})
        self.write(cr, uid, ids, {'state':'done'})
        return True
        
stock_delivery_fulfillment()

class delivery_fulfillment_planned_lines(osv.osv):
    
    _name = 'delivery.fulfillment.planned.lines'
    
    _columns = {
        'order_id': fields.many2one('sale.order','Sale Order'),
        'line_id1': fields.many2one('stock.delivery.fulfillment.line','fullfillment'),
        'date': fields.date('Date'),
        'lot_id': fields.many2one('stock.production.lot','Serial Number'),
        'weight': fields.float('UOS quantity'),
        'actual_qty': fields.float('Available Quantity'),
        'date_qty': fields.float('Actual Quantity'),
        'plan_qty': fields.float('Planned Quantity'),
        'location_id': fields.many2one('stock.location','Bin Location'),
    }

delivery_fulfillment_planned_lines()

class stock_delivery_fulfillment_line(osv.osv):
    _inherit = "stock.delivery.fulfillment.line"   
    _columns = {
                'planned_lines' :fields.one2many('delivery.fulfillment.planned.lines',
                                                          'line_id1','Lines'),
                'backorder_needed': fields.boolean('Consider for Backorder',
                        help="If checked, then it will be considered for creating sale quotation."),
                }
 
    def open_fulfillment_line(self,cr, uid, ids, context=None):
        res = super(stock_delivery_fulfillment_line,self).open_fulfillment_line(cr, uid, ids, context)
        plannig_id = res['res_id']
        prodlot_pool = self.pool.get('stock.production.lot')
        location_pool = self.pool.get('stock.location')
        for obj in self.browse(cr, uid, ids, context):
            wiz_data = {}
            if context.get('plan_state','') == 'done':
                  wiz_data = {'backorder_needed':obj.backorder_needed}
            wiz_data.update({
               'uos_id': obj.product_id.uos_id.id,
               'sale_description': obj.sale_line_id.name or '',
#                'backorder_needed':obj.backorder_needed,
               'line_ids2':[(0,0,{
                    'date': plan_line.lot_id.date or False,
                    'lot_id': plan_line.lot_id.id or False,
                    'actual_qty':plan_line.actual_qty if context.get('plan_state',False) == 'done' else prodlot_pool.browse(cr, uid, plan_line.lot_id.id,
                                context={'location_id':plan_line.location_id.id}).stock_available,
                    'date_qty': plan_line.date_qty ,
                    'plan_qty': plan_line.plan_qty ,
                    'weight': plan_line.weight or obj.product_id.uos_coeff * plan_line.date_qty,
                    'location_id': plan_line.location_id and plan_line.location_id.id,
                    'location_id1': plan_line.location_id and plan_line.location_id.name
                }) for plan_line in obj.planned_lines]
            })
            self.pool.get('delivery.fulfillment.wizard').write(cr, uid,plannig_id, wiz_data)

        return res

    def create_delivery_fullfillment(self, cr, uid, ids,planning_id, 
                                     customer_plan_ids, context=None):
        fulfillment_id = super(stock_delivery_fulfillment_line,self).create_delivery_fullfillment(cr, uid, ids,planning_id,customer_plan_ids, context)
        fulfillment_pool = self.pool.get('stock.delivery.fulfillment')
        customer_plan_pool = self.pool.get('stock.dispatch.planning.customer')
        location_pool = self.pool.get('stock.location')
        prodlot_pool = self.pool.get('stock.production.lot')
        fulfiment_record = fulfillment_pool.browse(cr, uid, fulfillment_id, context)
        self.pool.get('stock.dispatch.planning').write(cr, uid, planning_id, {'fulfillment_id': fulfillment_id},context)
        for line in fulfiment_record.fullfilment_line_ids:
            self.write(cr, uid, line.id, {'actual_qty': line.planned_qty,
                                          'is_loaded': True,
                                          'state': 'approved'
                                          } )
            lot_loc_dict = {}
            plan_lines_dict = {}
            for move in line.move_lines:
                if (move.prodlot_id.id,move.location_id.id) not in lot_loc_dict:
                    lot_loc_dict[ (move.prodlot_id.id,move.location_id.id)] = {'loc':move.location_id.id,
                                                        'move_obj': move,
                                                        'move_id':move.id}
            move_list = [move for move in line.move_lines]
            move_lot_list = [move.prodlot_id for move in line.move_lines]
            lot_ids = prodlot_pool.search(cr,uid,[('product_id','=',line.product_id.id),
                                    ('stock_available','>',0.0)],context={'location_id':line.location_id.id})
            if line.product_id.is_frozen == True:
               lot_ids =  lot_ids[::-1]
            loc_ids = location_pool.search(cr, uid, [('id','child_of',line.location_id.id)])
            for lot_id in lot_ids:
                for loc_id in loc_ids:
                    avail_lot_ids = prodlot_pool.search(cr, uid, [('id','=',lot_id),('stock_available','>',0.0)],
                                                        context={'location':loc_id})
                    if not avail_lot_ids:
                        continue
                    lot_data = prodlot_pool.read(cr, uid, avail_lot_ids, [],context={'location':loc_id})[0]
                    if lot_data['stock_available'] <= 0.0:
                        continue
                    qty = 0.00
                    weight = 0.00
                    location_id = loc_id
                    if (lot_data['id'],loc_id) in lot_loc_dict:
                        move = lot_loc_dict[(lot_data['id'], loc_id)]["move_obj"]
                        qty = move.plan_qty
                        weight = move.product_uos_qty
                    self.pool.get('delivery.fulfillment.planned.lines').create(cr, uid,{  
                              'date': lot_data['date'] or False,
                              'lot_id': lot_data['id'] or False,
                              'date_qty': qty,
                              'plan_qty': qty,
                              'weight': weight,
                              'location_id': location_id or False,
                              'line_id1': line.id
                          },context=context)
                    location_id = move.location_id.id
        return fulfillment_id
        
stock_delivery_fulfillment_line()  

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
              